/**
 * 
 */
/**
 * @author mariana.goncalves
 *
 */
module AtividadePratica2 {
	requires java.desktop;
}