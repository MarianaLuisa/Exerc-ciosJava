package atividade1;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.HeadlessException;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.BoxLayout;
import java.awt.CardLayout;
import java.awt.Font;
import java.awt.Dimension;
import java.awt.Rectangle;

public class Calculadora extends JFrame {
	
	private JTextField textField;
	private JPanel contentPane;
	private JButton c11;

	public Calculadora() 
	{
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 249, 328);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		
		setContentPane(contentPane);
		contentPane.setLayout(new BorderLayout(0, 0));
		/*setLocation(new Point(249, 328));
		getContentPane().setLayout(new BorderLayout(550, 500));*/

		
		JPanel panel = new JPanel();
		panel.setPreferredSize(new Dimension(10, 40));
		panel.setFont(new Font("Tahoma", Font.PLAIN, 25));
		contentPane.add(panel, BorderLayout.NORTH);
		panel.setLayout(new BorderLayout(0, 0));
		
		textField = new JTextField();
		textField.setFont(new Font("Tahoma", Font.PLAIN, 20));
		textField.setPreferredSize(new Dimension(7, 30));
		panel.add(textField, BorderLayout.CENTER);
		textField.setColumns(10);
		
		/*JPanel painel1 = new JPanel();
		getContentPane().add(painel1);
		painel1.setLayout(new BorderLayout(9, 9));*/

		/*textField = new JTextField();
		textField.setLocation(new Point(249, 328));
		painel1.add(textField, BorderLayout.NORTH);
		textField.setColumns(10);*/

		JPanel painel3 = new JPanel();
		FlowLayout flowLayout = (FlowLayout) painel3.getLayout();
		flowLayout.setAlignment(FlowLayout.LEFT);
		contentPane.add(painel3, BorderLayout.SOUTH);
		
		/*getContentPane().add(painel3);
		painel3.setLayout(new FlowLayout(FlowLayout.LEFT, 5, 5));*/

		JButton calcular = new JButton("Calcular");
		calcular.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		calcular.setHorizontalAlignment(SwingConstants.LEFT);
		painel3.add(calcular);
		
		//painel3.add(calcular);

		JPanel painel2 = new JPanel();
		getContentPane().add(painel2);
		painel2.setLayout(new GridLayout(4, 4, 0, 0));

		JButton a = new JButton("1");
		a.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		painel2.add(a);

		JButton b = new JButton("2");
		painel2.add(b);

		JButton c = new JButton("3");
		painel2.add(c);

		JButton mais = new JButton("+");
		painel2.add(mais);

		JButton d = new JButton("4");
		painel2.add(d);

		JButton e = new JButton("5");
		painel2.add(e);

		JButton f = new JButton("6");
		painel2.add(f);

		JButton menos = new JButton("-");
		painel2.add(menos);

		JButton g = new JButton("7");
		painel2.add(g);

		JButton h = new JButton("8");
		painel2.add(h);

		JButton i = new JButton("9");
		painel2.add(i);

		JButton barra = new JButton("/");
		painel2.add(barra);

		JButton j = new JButton("0");
		painel2.add(j);

		JButton chapeu = new JButton("^");
		painel2.add(chapeu);

		c11 = new JButton("C");
		painel2.add(c11);

		JButton ce = new JButton("CE");
		painel2.add(ce);
		
	}
	
	private JButton c1;
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}
	
		public static void main(String[] args) {
			Calculadora cal = new Calculadora();
			cal.setVisible(true);
		
	}


	

}