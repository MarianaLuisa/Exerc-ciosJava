/**
 * 
 */
/**
 * @author Mariana
 *
 */
module AP2 {
	requires java.desktop;
}