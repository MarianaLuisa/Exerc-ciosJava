package controle;

import dao.DAO;
import modelo.CotacaoMoeda;
import visao.JanelaCotacao;

public class App {
	
	public static void main(String[] args) {
		
		JanelaCotacao janela = new JanelaCotacao();
		janela.setVisible(true);
		CotacaoMoeda cmoeda = new CotacaoMoeda();
		DAO dao = new DAO();
		
		CotacaoControle cc = new CotacaoControle(janela, cmoeda);
	}

}
