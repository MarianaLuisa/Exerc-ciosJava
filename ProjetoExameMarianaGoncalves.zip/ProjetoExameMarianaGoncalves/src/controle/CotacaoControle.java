package controle;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import dao.DAO;
import modelo.CotacaoMoeda;
import visao.JanelaCotacao;

public class CotacaoControle implements ActionListener {

	private JanelaCotacao janela;
	private CotacaoMoeda cotacao;
	private DAO dao;

	public CotacaoControle(JanelaCotacao janela, CotacaoMoeda cotacao) {
		super();
		this.janela = janela;
		this.cotacao = cotacao;
		dao = new DAO();
		this.janela.getButtonConsultar().addActionListener(this);
	}

	public void consultaMoeda() {
		
		cotacao.setDia(janela.getFieldDia().getText());
		cotacao.setMoeda(janela.getFieldMoeda().getText());

		if (cotacao.validaCampos().size() > 0) {
			
			System.out.println("Campos: " + cotacao.validaCampos() + " em branco.");
			
		}else if (dao.consultaMoeda(cotacao)) {
			
			janela.getLabelCotacao().setText(cotacao.getCotacaoReal());
		}  
		else {
			
			System.out.println("Cotação não encontrada!");
		}
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if (e.getActionCommand().equals("Consultar")) {
			consultaMoeda();
		}
	}

}