package modelo;

import java.util.ArrayList;
import java.util.List;

public class CotacaoMoeda {
	
	private String dia, moeda, cotacaoReal;
	

	public CotacaoMoeda(String dia, String moeda, String cotacaoReal) {
		super();
		this.dia = dia;
		this.moeda = moeda;
		this.cotacaoReal = cotacaoReal;
	}
	
	public CotacaoMoeda() {
	}

	public String getDia() {
		return dia;
	}

	public void setDia(String dia) {
		this.dia = dia;
	}

	public String getMoeda() {
		return moeda;
	}

	public void setMoeda(String moeda) {
		this.moeda = moeda;
	}

	public String getCotacaoReal() {
		return cotacaoReal;
	}

	public void setCotacaoReal(String cotacaoReal) {
		this.cotacaoReal = cotacaoReal;
	}
	
	public String toString() {
		
		return cotacaoReal;
	}
	
	public List<String> validaCampos(){

        ArrayList<String> listaCampos= new ArrayList<String>();

        if(dia.equals("")) {
            listaCampos.add("Dia");
        }
        if(moeda.equals("")) {
            listaCampos.add("Moeda");
        }
        return listaCampos;
    }

}
