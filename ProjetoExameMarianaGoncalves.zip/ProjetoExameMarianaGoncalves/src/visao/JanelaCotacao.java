package visao;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import net.miginfocom.swing.MigLayout;
import javax.swing.JLabel;
import javax.swing.JTextField;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.SwingConstants;

public class JanelaCotacao extends JFrame {

	private JPanel contentPane;
	private JButton buttonConsultar;
	private JTextField fieldMoeda;
	private JTextField fieldDia;
	private JLabel labelCotacao;
	private JLabel labelReal;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					JanelaCotacao frame = new JanelaCotacao();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public JanelaCotacao() {
		setTitle("Cotação de Moedas - Janeiro");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setResizable(true);
		setBounds(100, 100, 450, 209);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(new MigLayout("", "[grow][grow][grow]", "[][][][][25px:n][]"));
		
		JLabel labelDia = new JLabel("Dia");
		labelDia.setFont(new Font("Tahoma", Font.PLAIN, 12));
		contentPane.add(labelDia, "cell 0 0");
		
		fieldDia = new JTextField();
		fieldDia.setFont(new Font("Tahoma", Font.PLAIN, 12));
		contentPane.add(fieldDia, "cell 0 1,growx");
		fieldDia.setColumns(10);
		
		labelCotacao = new JLabel("");
		labelCotacao.setFont(new Font("Tahoma", Font.BOLD, 20));
		contentPane.add(labelCotacao, "cell 1 1,alignx right");
		
		labelReal = new JLabel("Reais");
		labelReal.setFont(new Font("Tahoma", Font.BOLD, 20));
		contentPane.add(labelReal, "cell 2 1");
		
		JLabel labelMoeda = new JLabel("Moeda");
		labelMoeda.setFont(new Font("Tahoma", Font.PLAIN, 12));
		contentPane.add(labelMoeda, "cell 0 2");
		
		fieldMoeda = new JTextField();
		fieldMoeda.setFont(new Font("Tahoma", Font.PLAIN, 12));
		contentPane.add(fieldMoeda, "cell 0 3,growx");
		fieldMoeda.setColumns(10);
		
		buttonConsultar = new JButton("Consultar");
		buttonConsultar.setFont(new Font("Tahoma", Font.PLAIN, 12));
		contentPane.add(buttonConsultar, "cell 0 5,growx,aligny center");
	}

	public JButton getButtonConsultar() {
		return buttonConsultar;
	}

	public void setButtonConsultar(JButton buttonConsultar) {
		this.buttonConsultar = buttonConsultar;
	}

	public JTextField getFieldMoeda() {
		return fieldMoeda;
	}

	public void setFieldMoeda(JTextField fieldMoeda) {
		this.fieldMoeda = fieldMoeda;
	}

	public JTextField getFieldDia() {
		return fieldDia;
	}

	public void setFieldDia(JTextField fieldDia) {
		this.fieldDia = fieldDia;
	}

	public JLabel getLabelCotacao() {
		return labelCotacao;
	}

	public void setLabelCotacao(JLabel labelCotacao) {
		this.labelCotacao = labelCotacao;
	}

	public JLabel getLabelReal() {
		return labelReal;
	}

	public void setLabelReal(JLabel labelReal) {
		this.labelReal = labelReal;
	}
}
