package atividade1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.LinkedList;
import java.util.Scanner;
import java.util.concurrent.LinkedBlockingDeque;

public class App {

	public static void main(String[] args) throws NumberFormatException, IOException {
		
		LinkedList<Funcionario> listaFunc= new LinkedList<Funcionario>();
		
		/*Funcionario[] vetFunc= new Funcionario [15];
		vetFunc [0]= new Vendedor("1234-55", "Maria", 1000);
		vetFunc[0].calculaSalario();
		
		vetFunc[1]= new Diretor("1234-22", "Carla", 10000);
		vetFunc[1].calculaSalario();
		
		vetFunc[2]= new Gerente("1234-66", "Marcos", 5000);
		vetFunc[2].calculaSalario();
		
		System.out.println("Salário Vendedor: "+vetFunc[0].getSalario());
		System.out.println("Salário Diretor: "+vetFunc[1].getSalario());
		System.out.println("Salário Gerente: "+vetFunc[2].getSalario());*/
		
		BufferedReader leitura = new BufferedReader(new InputStreamReader(System.in));
		String mAux, nAux;
		float salAux;
		int flag=1;
		int tipo;
		
		do
		{
			System.out.println("Informe matrícula, nome e salário");
			mAux=leitura.readLine();
			nAux=leitura.readLine();
			salAux=Float.parseFloat(leitura.readLine());
			
			System.out.println("Escolha o tipo de funcionário: (1-Vendedor, 2-Gerente, 3-Diretor");
			tipo=Integer.parseInt(leitura.readLine());
			
			if(tipo==1)
				listaFunc.add(new Vendedor(mAux, nAux, salAux));
			else if(tipo==2)
				listaFunc.add(new Gerente(mAux, nAux, salAux));
			else if (tipo==3)
				listaFunc.add(new Diretor(mAux, nAux, salAux));
			
			System.out.println("Deseja continuar? (1-Sim, 2-Não)");
			flag=Integer.parseInt(leitura.readLine());
			
			//listFunc.add(new Funcionario(mAux, nAux, salAux));
			
		}
		while(flag==1);
		
		leitura.close();
		
		for (int i = 0; i < listaFunc.size(); i++)
				{
					System.out.println(listaFunc.get(i));
				}
		
			
	}
	
}
