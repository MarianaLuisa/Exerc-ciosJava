package atividade1;

public class Cliente {

}
