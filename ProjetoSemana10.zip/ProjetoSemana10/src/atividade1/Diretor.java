package atividade1;

public class Diretor extends Funcionario {

	public Diretor(String matricula, String nome, float salario) {
		super(matricula, nome, salario);
		// TODO Auto-generated constructor stub
	}
	
	public void calculaSalario()
	{
	salario=salario*1.30f;
	}

}
