package atividade1;

public class Funcionario {
	
	protected String matricula;
	protected String nome;
	protected float salario;
	
	public Funcionario(String matricula, String nome, float salario) {
		super();
		this.matricula = matricula;
		this.nome = nome;
		this.salario = salario;
	}
	public String getMatricula() {
		return matricula;
	}
	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public float getSalario() {
		return salario;
	}
	public void setSalario(float salario) {
		this.salario = salario;
	}
	
	public void calculaSalario()
	{
		salario=salario*1.05f;
	}
	
	public String toString()
	{
		return "Nome: "+nome;
	}
	
}
