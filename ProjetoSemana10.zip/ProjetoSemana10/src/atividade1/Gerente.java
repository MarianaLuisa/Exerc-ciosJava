package atividade1;

public class Gerente extends Funcionario{

	public Gerente(String matricula, String nome, float salario) {
		super(matricula, nome, salario);
		// TODO Auto-generated constructor stub
	}

	public void calculaSalario()
	{
		salario=salario*1.20f;
	}
}
