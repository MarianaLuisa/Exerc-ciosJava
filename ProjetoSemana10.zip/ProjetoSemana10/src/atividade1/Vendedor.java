package atividade1;

public class Vendedor extends Funcionario{

	public Vendedor(String matricula, String nome, float salario) {
		super(matricula, nome, salario);
		// TODO Auto-generated constructor stub
	}
	
	public void calculaSalario()
	{
	salario=salario*1.10f;
	}

}
