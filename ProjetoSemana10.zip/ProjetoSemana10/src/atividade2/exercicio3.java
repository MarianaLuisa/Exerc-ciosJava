package atividade2;

public class exercicio3 {
	
	class Prog1 {
		public static void main(String[] args) {
		String[] data = {"Larry", "Moe", null, "Curly"};
		try {
		for(String s : data)
		System.out.println(s.length());
		}
		catch (Exception exc) { }
		}
		}

}
