package atividade1;

import javax.swing.JFrame;

public class PrimeiraJanela {
	
	public static void main(String[] args) {
		
		JFrame janela = new JFrame();
		janela.setVisible(true);
		janela.setTitle("Primeira Janela");
		janela.setBounds(100, 200, 800, 600);
		janela.setResizable(true);
		
	
	}

}
