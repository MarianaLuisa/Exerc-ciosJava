package atividade1;

import javax.swing.JButton;
import javax.swing.JFrame;

public class SegundaJanela extends JFrame {
	
	public SegundaJanela()
	{
		setTitle("Minha Segunda Janela");
		setBounds(100, 100, 800, 500);
		JButton botao= new JButton("Aperte-me");
		getContentPane().add(botao);
		setLayout(null);
		botao.setBounds(220, 150, 80, 50);
		
	}
	
	public static void main(String[] args) {
		
		SegundaJanela segJan= new SegundaJanela();
		segJan.setVisible(true);
		
	}
	

}
