package atividade2;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Color;
import javax.swing.JTextField;

public class JanelaPrincipal extends JFrame {

	private JPanel contentPane;
	private JTextField FieldNome;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					JanelaPrincipal frame = new JanelaPrincipal();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public JanelaPrincipal() {
		setTitle("Minha Janela\r\n");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 502, 417);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(102, 204, 255));
		contentPane.setForeground(new Color(0, 0, 0));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));


		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel LabelNome = new JLabel("Nome");
		LabelNome.setBounds(52, 69, 69, 31);
		LabelNome.setBackground(new Color(255, 51, 255));
		LabelNome.setFont(new Font("Sitka Small", Font.ITALIC, 11));
		contentPane.add(LabelNome);
		
		FieldNome = new JTextField();
		FieldNome.setBackground(new Color(153, 255, 255));
		FieldNome.setText("Mariana Luísa");
		FieldNome.setBounds(131, 72, 134, 20);
		contentPane.add(FieldNome);
		FieldNome.setColumns(10);
	}
}
