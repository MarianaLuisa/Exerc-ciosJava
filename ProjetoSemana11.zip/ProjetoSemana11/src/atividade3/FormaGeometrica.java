package atividade3;

public interface FormaGeometrica {
	
	public double calcularArea();
	
	
	
	

}
