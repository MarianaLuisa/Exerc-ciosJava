/**
 * 
 */
/**
 * @author mariana.goncalves
 *
 */
module ProjetoSemana11 {
	requires java.desktop;
}