package atividade2;

import javax.swing.JPanel;
import java.awt.Color;

public class TelaPainel1 extends JPanel{
	
	public TelaPainel1()
	{
		setBackground(Color.PINK);
		setBounds(0, 0, 600, 300);
	}

	
	
}
