package atividade2;

import javax.swing.JPanel;
import java.awt.Color;

public class TelaPainel2 extends JPanel {
	
	public TelaPainel2()
	{
		setBackground(Color.CYAN);
		setBounds(0, 0, 600, 300);
	}

}
