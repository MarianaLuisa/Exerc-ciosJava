package dao;


import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import modelo.Cliente;

public class ClienteDAO {
	
	private File arq;
	private FileWriter fw;
	private BufferedWriter bw;

	public ClienteDAO()
	{
		arq=new File("dados.txt");
	}

	public boolean cadastraCliente(Cliente c) {

		
			try {
				fw = new FileWriter(arq, true);
				bw = new BufferedWriter(fw);

				bw.write(c.toString());
				bw.newLine();
				bw.flush();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return false;
			}
			finally {
				try {
					fw.close();
					bw.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			}
			
			return true;

	}

}
