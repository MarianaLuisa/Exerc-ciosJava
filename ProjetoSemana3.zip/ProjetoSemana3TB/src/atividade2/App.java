package atividade2;

public class App {
	
	public static void main(String[] args) {
		
		Cliente c1= new Cliente("Luciano", 12345);
		c1.setNome("Maria");
		System.out.println("Nome: "+c1.getNome());
		
		Cliente c2= new Cliente();
		Cliente c3= new Cliente();
		
		System.out.println("Nome de C2: "+c2.getNome());
		System.out.printf("Nome de C3: %s ", c3.getNome());
		
		Cliente.metodoStatic();
		Math.sqrt(4.0);
		
	
	}

}
