package atividade2;

public class Cliente {
	
	private static String nome;
	private long cpf;
	
	
	public Cliente(String nome, long cpf) {
		super();
		this.nome = nome;
		this.cpf = cpf;
	}
	
	public Cliente() {

	}
	
	public String getNome() {
		return nome;
	}


	public void setNome(String nome) {
		this.nome = nome;
	}


	public long getCpf() {
		return cpf;
	}


	public void setCpf(long cpf) {
		this.cpf = cpf;
	}
	
	public static void metodoStatic()
	{
		System.out.println("Faz alguma coisa");
	}
}
