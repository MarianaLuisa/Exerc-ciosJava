package atividade3;

public class ExemploMath {
	
	public static void main(String[] args) {
		
		double num=16;

		System.out.println("Raiz de num: "+Math.sqrt(num));
	}

}
