package atividade4;

public class App {
	
	public static void main(String[] args) {
		
		Carro c1= new Carro("Vermelha", "Ford", "IZF1223");
		System.out.printf("Cor: %s",c1.getCor());
		System.out.println("\nMarca: "+c1.getMarca());
		System.out.println("Placa: "+c1.getPlaca());
		
		Cadeira cad1= new Cadeira("Preta", "Borracha", 4);
	}

}
