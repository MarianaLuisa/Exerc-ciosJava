package atividade4;

public class Cadeira {
	
	private String cor, material;
	private int numPernas;
	
	public Cadeira(String cor, String material, int numPernas) {
		super();
		this.cor = cor;
		this.material = material;
		this.numPernas = numPernas;
	}

	public String getCor() {
		return cor;
	}

	public void setCor(String cor) {
		this.cor = cor;
	}

	public String getMaterial() {
		return material;
	}

	public void setMaterial(String material) {
		this.material = material;
	}

	public int getNumPernas() {
		return numPernas;
	}

	public void setNumPernas(int numPernas) {
		this.numPernas = numPernas;
	}

}
