package atividade4.a;

public class App {
	
	public static void main(String[] args)
	{
		Livro l1= new Livro("Romance", 200);
		Livro l2= new Livro("Suspense", 300);
		
		System.out.println("Gênero: "+l1.getGenero());
		System.out.println("Número de páginas: "+l1.getNumpag());
		
		Celular c1= new Celular("Apple", 30);
		Celular c2= new Celular("Samsung", 40);
		
		System.out.println("Modelo: "+c1.getModelo());
		System.out.println("Peso: "+c1.getPeso());
		System.out.println("Modelo: "+c2.getModelo());
		System.out.println("Peso: "+c2.getPeso);
		
	}
	
	

}
