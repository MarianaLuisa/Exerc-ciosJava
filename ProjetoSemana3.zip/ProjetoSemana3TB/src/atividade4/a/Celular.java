package atividade4.a;

public class Celular {
	
	private String modelo;
	private float peso;
	public Celular(String modelo, float peso) {
		super();
		this.modelo = modelo;
		this.peso = peso;
	}
	public String getModelo() {
		return modelo;
	}
	public void setModelo(String modelo) {
		this.modelo = modelo;
	}
	public float getPeso() {
		return peso;
	}
	public void setPeso(float peso) {
		this.peso = peso;
	}
	
	
	
}
