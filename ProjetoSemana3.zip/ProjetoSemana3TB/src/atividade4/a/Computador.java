package atividade4.a;

public class Computador {
	
	private int memoria;
	private char importado;
	public Computador(int memoria, char importado) {
		super();
		this.memoria = memoria;
		this.importado = importado;
	}
	public int getMemoria() {
		return memoria;
	}
	public void setMemoria(int memoria) {
		this.memoria = memoria;
	}
	public char getImportado() {
		return importado;
	}
	public void setImportado(char importado) {
		this.importado = importado;
	}
	
	

}
