package atividade4.a;

public class Livro {
	
	private String genero;
	private int numpag;
	public Livro(String genero, int numpag) {
		super();
		this.genero = genero;
		this.numpag = numpag;
	}
	public String getGenero() {
		return genero;
	}
	public void setGenero(String genero) {
		this.genero = genero;
	}
	public int getNumpag() {
		return numpag;
	}
	public void setNumpag(int numpag) {
		this.numpag = numpag;
	}
	
	

}
