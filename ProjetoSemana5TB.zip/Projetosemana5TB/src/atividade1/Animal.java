package atividade1;

public abstract class Animal {
	
	protected String nome;
	protected String raça;
	
	public Animal(String nome, String raça) {
		super();
		this.nome = nome;
		this.raça = raça;
	}
	
	public void respirar()
	{
		System.out.println("Animal respirando");
	}
	
	public abstract void fazerBarulho();
	
	
	

}
