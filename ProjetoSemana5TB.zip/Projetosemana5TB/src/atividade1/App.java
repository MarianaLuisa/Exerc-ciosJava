package atividade1;

public class App {
	
	public static void main(String[] args) {
		
		//Animal a= new Animal("XXXX", "YYYY");
				
		Gato g= new Gato("Garfield", "Persa");
		Cachorro c= new Cachorro("Tom", "Vira lata");
		
		System.out.println("Nome do gato: "+g.nome);
		g.fazerBarulho();
		
		System.out.println("\nNome do cachorro: "+c.nome);
		c.fazerBarulho();

	}

}
