package atividade1;

public class Cachorro extends Animal{

	public Cachorro(String nome, String raça) {
		super(nome, raça);
		// TODO Auto-generated constructor stub
	}
	
	public void caçarGato()
	{
		System.out.println("cachorro caçando gato");
	}
	
	public void fazerBarulho()
	{
		System.out.println("au au");
	}

}
