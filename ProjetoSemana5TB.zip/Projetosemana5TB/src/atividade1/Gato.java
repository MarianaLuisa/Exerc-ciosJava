package atividade1;

public class Gato extends Animal {

	public Gato(String nome, String raça) {
		super(nome, raça);
		// TODO Auto-generated constructor stub
	}
	
	public void caçarRato()
	{
		System.out.println("Gato caçando rato");
	}
	
	public void fazerBarulho()
	{
		System.out.println("miau");
	}
	
	
}
