package atividade2;

public class App {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Secretario s= new Secretario("José", 12345, 1000);
		System.out.println("Salário do Secretário: "+s.calculaSalario());
		
		Diretor d= new Diretor("Maria", 333333, 10000);
		System.out.println("Salário da Diretora: "+d.calculaSalario());
		
		Gerente g= new Gerente("Carlos", 44444, 5000);
		System.out.println("Salário do Gerente: "+g.calculaSalario());
		

	}

}
