package atividade2;

public class Diretor extends Funcionario{

	public Diretor(String nome, int cpf, double salario) {
		super(nome, cpf, salario);
		// TODO Auto-generated constructor stub
	}
	
	public void administraFilial()
	{
		System.out.println("Diretor administrando filial");
	}
	
	public double calculaSalario()
	{
		return salario * 1.30;
	}

}
