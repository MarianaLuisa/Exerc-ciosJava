package atividade2;

public class Funcionario {
	
	protected String nome;
	protected int cpf;
	protected double salario;
	
	public Funcionario(String nome, int cpf, double salario) {
		super();
		this.nome = nome;
		this.cpf = cpf;
		this.salario = salario;
	}
	
	public double calculaSalario()
	{
		return salario * 1.05;
	}
	
	

}
