package atividade2;

public class Gerente extends Funcionario{

	public Gerente(String nome, int cpf, double salario) {
		super(nome, cpf, salario);
		// TODO Auto-generated constructor stub
	}
	
	public void supervisionaFunc()
	{
		System.out.println("Gerente supervisionando funcionário");
	}
	
	public double calculaSalario()
	{
		return salario * 1.20;
	}

}
