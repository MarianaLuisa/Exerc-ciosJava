package atividade2;

public class Secretario extends Funcionario {
	
	public Secretario(String nome, int cpf, double salario) {
		super(nome, cpf, salario);
		// TODO Auto-generated constructor stub
	}

	public void atendeTelefone()
	{
		System.out.println("Secretário atendendo telefone");
	}

}
