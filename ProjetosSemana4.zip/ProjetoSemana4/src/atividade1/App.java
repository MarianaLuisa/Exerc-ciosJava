package atividade1;

import java.io.IOException;
import java.util.Iterator;

public class App {
	
	public static void main(String[] args) throws IOException {
		
		//System.out.write(100);
		//System.out.flush();
		
		System.out.println("Informe uma palavra: ");
		byte data[]= new byte [10];
		
		int numRead= System.in.read(data);
		
		for (int i = 0; i < data.length; i++) {
			
			System.out.print((char)data[i]);
			
		}
		
	
	}

}
