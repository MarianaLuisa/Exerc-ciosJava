package atividade1;

import java.util.Scanner;

public class ExemploScanner {
	
	public static void main(String[] args)
	{ 
		Scanner leitura= new Scanner(System.in);
		
		System.out.println("Informe os dados do teclado: ");
		
		System.out.println("\nMarca: ");
		String marca=leitura.nextLine();
		
		System.out.println("\nPeso: ");
		float peso=leitura.nextFloat();
		
		System.out.println("\nAno de fabricação: ");
		int anofab=leitura.nextInt();
		
		Teclado tec= new Teclado(marca, peso, anofab);
		
		System.out.println("Marca do teclado: "+tec.getMarca());

		System.out.println("Peso do teclado: "+tec.getPeso());

		System.out.println("Ano de fabricação do teclado: "+tec.getAnofab());
	}

}
