package atividade1;

public class Teclado {
	
	private String marca;
	private float peso;
	private int anofab;
	public Teclado(String marca, float peso, int anofab) {
		super();
		this.marca = marca;
		this.peso = peso;
		this.anofab = anofab;
	}
	public String getMarca() {
		return marca;
	}
	public void setMarca(String marca) {
		this.marca = marca;
	}
	public float getPeso() {
		return peso;
	}
	public void setPeso(float peso) {
		this.peso = peso;
	}
	public int getAnofab() {
		return anofab;
	}
	public void setAnofab(int anofab) {
		this.anofab = anofab;
	}
	
	

}
