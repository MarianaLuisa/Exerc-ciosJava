package atividade2;

public class App {

	public static void main (String[] args)
	{ 
		/*Lampada lamp= new Lampada();
		lamp.acende();
		lamp.mostraestado();
		
		ContaBancaria conta= new ContaBancaria("Mariana", 1000, true);
		
		conta.deposita(500);
		conta.retira(200);
		conta.mostraDados();*/
		
		RegistroAcademico registro= new RegistroAcademico("Mariana", 123, true);
		
		reg.mostraRegistro();
		reg.calculaMensalidade();
		
	}
	
}
