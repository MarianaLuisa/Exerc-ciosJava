package atividade2;

public class ContaBancaria {
	
	
	private String nomeCorrentista;
	private float saldo;
	private boolean contaEspecial;
	
	
	public ContaBancaria(String nomeCorrentista, float saldo, boolean contaEspecial) {
		super();
		this.nomeCorrentista = nomeCorrentista;
		this.saldo = saldo;
		this.contaEspecial = contaEspecial;
	}

	public void deposita(float val)
	{
		saldo=saldo+val;
	}
	
	public void retira(float val)
	{ 
		saldo=saldo-val;
	}
	
	public void mostraDados()
	{
		System.out.println("Saldo: "+saldo);
	}
	
}
