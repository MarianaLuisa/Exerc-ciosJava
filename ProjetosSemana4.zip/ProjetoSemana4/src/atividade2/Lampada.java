package atividade2;

public class Lampada {
	
	private String estadoDaLampada;

	public Lampada() {
		super();
		this.estadoDaLampada = "apagada";
	}
	
	
	public void acende()
	{
		this.estadoDaLampada="acesa";
	}
	
	public void apaga()
	{
		this.estadoDaLampada="apagada";
	}
	
	public void mostraestado()
	{
		System.out.println(estadoDaLampada);
	}
	
	
	
	

}

