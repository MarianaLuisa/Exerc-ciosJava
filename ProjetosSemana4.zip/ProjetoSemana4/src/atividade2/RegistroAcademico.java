package atividade2;

public class RegistroAcademico {
	
	private String nomeAluno;
	private int numeroMatricula;
	private boolean eBolsista;
	
	
	public RegistroAcademico(String nomeAluno, int numeroMatricula, boolean eBolsista) {
		super();
		this.nomeAluno = nomeAluno;
		this.numeroMatricula = numeroMatricula;
		this.eBolsista = eBolsista;
	}
	
	
	public void calculaMensalidade(float valMensalidade)
	{
		if (ebolsista)
			System.out.println("Valor da mensalidade: "+val * 0.5);
		else 
			System.out.println("Valor da mensalidade: "+val);
	}
	
	public void mostraRegistro()
	{
		System.out.println("Nome: "+nomeAluno);

		System.out.println("Matrícula: "+numeroMatricula);

		if (eBolsista)
			System.out.println("É bolsista? Sim);
		else 
			System.out.println("É bolsista? Não");
	}

}
