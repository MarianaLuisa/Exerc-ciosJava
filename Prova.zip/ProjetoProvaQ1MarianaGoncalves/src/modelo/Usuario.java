package modelo;

public class Usuario {
	
	public String Usuario;
	public int senha;
	
	public Usuario(String usuario, int senha) {
		super();
		Usuario = usuario;
		this.senha = senha;
	}

	public String getUsuario() {
		return Usuario;
	}

	public void setUsuario(String usuario) {
		Usuario = usuario;
	}

	public int getSenha() {
		return senha;
	}

	public void setSenha(int senha) {
		this.senha = senha;
	}
	
	

}
