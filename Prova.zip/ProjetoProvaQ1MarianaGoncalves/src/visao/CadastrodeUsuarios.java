package visao;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.SwingConstants;
import java.awt.FlowLayout;
import javax.swing.BoxLayout;
import java.awt.CardLayout;
import java.awt.Label;
import java.awt.Font;

public class CadastrodeUsuarios extends JFrame {

	private JPanel contentPane;
	private JTextField fieldUsuario;
	private JTextField fieldSenha;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CadastrodeUsuarios frame = new CadastrodeUsuarios();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public CadastrodeUsuarios() {
		setTitle("Tela de Cadastro de Usuários");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 335, 220);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(new BorderLayout(0, 0));
		
		JPanel panel = new JPanel();
		contentPane.add(panel);
		panel.setLayout(new GridLayout(0, 1, 4, 0));
		
		JLabel labelusuario = new JLabel("Usuário");
		labelusuario.setFont(new Font("Arial", Font.PLAIN, 14));
		panel.add(labelusuario);
		
		fieldUsuario = new JTextField();
		fieldUsuario.setFont(new Font("Arial", Font.PLAIN, 14));
		panel.add(fieldUsuario);
		fieldUsuario.setColumns(10);
		
		JLabel labelSenha = new JLabel("Senha");
		labelSenha.setFont(new Font("Arial", Font.PLAIN, 14));
		panel.add(labelSenha);
		
		fieldSenha = new JTextField();
		fieldSenha.setFont(new Font("Arial", Font.PLAIN, 14));
		panel.add(fieldSenha);
		fieldSenha.setColumns(10);
		
		JPanel panelCadastar = new JPanel();
		contentPane.add(panelCadastar, BorderLayout.SOUTH);
		panelCadastar.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
		
		JButton buttonCadastrar = new JButton("Cadastrar");
		buttonCadastrar.setFont(new Font("Arial", Font.PLAIN, 14));
		panelCadastar.add(buttonCadastrar);
	}
	
	

}
