package questao2;

public class Administrador extends Empregado{
	
	private String cra;
	private boolean ajudadecusto;
	
	public Administrador(int matricula, String cpf, String nome, String cra, boolean ajudadecusto) {
		super(matricula, cpf, nome);
		this.cra = cra;
		this.ajudadecusto = ajudadecusto;
	}

	public String getCra() {
		return cra;
	}

	public void setCra(String cra) {
		this.cra = cra;
	}

	public boolean isAjudadecusto() {
		return ajudadecusto;
	}

	public void setAjudadecusto(boolean ajudadecusto) {
		this.ajudadecusto = ajudadecusto;
	}
	

}
