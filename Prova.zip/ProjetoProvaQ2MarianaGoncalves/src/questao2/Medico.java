package questao2;

public class Medico extends Empregado{
	
	private String crm;
	private String especialidade;
	
	public Medico(int matricula, String cpf, String nome, String crm, String especialidade) {
		super(matricula, cpf, nome);
		this.crm = crm;
		this.especialidade = especialidade;
	}

	public String getCrm() {
		return crm;
	}

	public void setCrm(String crm) {
		this.crm = crm;
	}

	public String getEspecialidade() {
		return especialidade;
	}

	public void setEspecialidade(String especialidade) {
		this.especialidade = especialidade;
	}
	
	
	
}
