package questao2;

public class Motorista extends Empregado {
	
	private String carteira;
	private char categoria;
	
	
	public Motorista(int matricula, String cpf, String nome, String carteira, char categoria) {
		super(matricula, cpf, nome);
		this.carteira = carteira;
		this.categoria = categoria;
	}


	public String getCarteira() {
		return carteira;
	}


	public void setCarteira(String carteira) {
		this.carteira = carteira;
	}


	public char getCategoria() {
		return categoria;
	}


	public void setCategoria(char categoria) {
		this.categoria = categoria;
	}
	
	
	
	

}
