package questao2;

import java.util.Scanner;

public class ProgramaPrincipal {
	
	private int matricula;
	private String cpf;
	private String nome;
	
	public static void main(String[] args) {
		
		Administrador adm = new Administrador(0, null, null, null, false);
		
		Medico med = new Medico(0, null, null, null, null);
		
		Motorista mot = new Motorista(0, null, null, null, 0);
		
		Scanner leitura = new Scanner(System.in);
		
		System.out.println("Informe a matricula: ");
		int matricula = leitura.nextInt();
		
		System.out.println("Informe o cpf: ");
		String cpf = leitura.nextLine();
		
		System.out.println("Informe o nome: ");
		String nome = leitura.nextLine();
		
	
	}

}
