package controle;

import modelo.Cliente;
import visao.JanelaCadastro;

public class App {
	
	public static void main(String[] args) {
		
		JanelaCadastro jan= new JanelaCadastro();
		jan.setVisible(true);
		Cliente cli = new Cliente();
		ClienteControle clicon = new ClienteControle(jan, cli);
	}

}
