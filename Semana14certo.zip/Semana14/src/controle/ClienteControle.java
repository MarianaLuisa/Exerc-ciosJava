package controle;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import dao.ClienteDAO;
import modelo.Cliente;
import visao.JanelaCadastro;

public class ClienteControle implements ActionListener {

	private JanelaCadastro janela;
	private Cliente cli;
	private ClienteDAO clidao;

	public ClienteControle(JanelaCadastro janela, Cliente cli) {
		this.janela = janela;
		this.cli = cli;
		clidao = new ClienteDAO();
		registraListenersAcao();
	}

	public void registraListenersAcao() {
		janela.getButtonCadastrar().addActionListener(this);
		janela.getButtonLimpar().addActionListener(this);
	}

	public void cadastraCliente() {
		String cpf = janela.getFieldCpf().getText();
		String nome = janela.getFieldNome().getText();
		String endereco = janela.getFieldEndereco().getText();
		String profissao = janela.getComboProfissao().getSelectedItem().toString();

		cli = new Cliente(cpf, nome, endereco, profissao);

		System.out.println(cli);

		if (cli.validaCampos().size() > 0) {
			System.out.println("Campos " + cli.validaCampos() + " em branco");
		} else {
			clidao.cadastraCliente(cli);
		}

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if (e.getActionCommand().equals("Cadastrar")) {
			cadastraCliente();
		} else if (e.getActionCommand().equals("Limpar")) {
			janela.limparTelaCadastro();
		}

	}

}
