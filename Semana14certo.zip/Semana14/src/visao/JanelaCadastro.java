package visao;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JButton;

public class JanelaCadastro extends JFrame {

	private JPanel contentPane;
	private JTextField fieldCpf;
	private JTextField fieldNome;
	private JTextField fieldEndereco;
	private JButton buttonCadastrar;
	private JButton buttonLimpar;
	private JComboBox<String> comboProfissao;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					JanelaCadastro frame = new JanelaCadastro();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public JanelaCadastro() {
		setTitle("Janela de Cadastro de Clientes");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 551, 221);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel labelCpf = new JLabel("CPF");
		labelCpf.setBounds(10, 23, 46, 14);
		contentPane.add(labelCpf);

		fieldCpf = new JTextField();
		fieldCpf.setBounds(41, 20, 146, 20);
		contentPane.add(fieldCpf);
		fieldCpf.setColumns(10);

		JLabel labelNome = new JLabel("Nome");
		labelNome.setBounds(211, 23, 46, 14);
		contentPane.add(labelNome);

		fieldNome = new JTextField();
		fieldNome.setBounds(254, 20, 270, 19);
		contentPane.add(fieldNome);
		fieldNome.setColumns(10);

		JLabel labelEndereco = new JLabel("Endereço");
		labelEndereco.setBounds(10, 71, 54, 14);
		contentPane.add(labelEndereco);

		fieldEndereco = new JTextField();
		fieldEndereco.setBounds(71, 68, 239, 20);
		contentPane.add(fieldEndereco);
		fieldEndereco.setColumns(10);

		JLabel labelProfissao = new JLabel("Profissão");
		labelProfissao.setBounds(320, 71, 68, 14);
		contentPane.add(labelProfissao);

		comboProfissao = new JComboBox<String>();
		comboProfissao.addItem(" ");
		comboProfissao.addItem("Médico");
		comboProfissao.addItem("Administrador");
		comboProfissao.addItem("Advogado");
		comboProfissao.addItem("Informata Biomédica");

		comboProfissao.setBounds(379, 67, 132, 22);
		contentPane.add(comboProfissao);

		buttonCadastrar = new JButton("Cadastrar");
		buttonCadastrar.setBounds(20, 127, 98, 23);
		contentPane.add(buttonCadastrar);

		buttonLimpar = new JButton("Limpar");
		buttonLimpar.setBounds(130, 127, 89, 23);
		contentPane.add(buttonLimpar);
	}

	public JTextField getFieldCpf() {
		return fieldCpf;
	}

	public void setFieldCpf(JTextField fieldCpf) {
		this.fieldCpf = fieldCpf;
	}

	public JTextField getFieldNome() {
		return fieldNome;
	}

	public void setFieldNome(JTextField fieldNome) {
		this.fieldNome = fieldNome;
	}

	public JTextField getFieldEndereco() {
		return fieldEndereco;
	}

	public void setFieldEndereco(JTextField fieldEndereco) {
		this.fieldEndereco = fieldEndereco;
	}

	public JButton getButtonCadastrar() {
		return buttonCadastrar;
	}

	public void setButtonCadastrar(JButton buttonCadastrar) {
		this.buttonCadastrar = buttonCadastrar;
	}

	public JButton getButtonLimpar() {
		return buttonLimpar;
	}

	public void setButtonLimpar(JButton buttonLimpar) {
		this.buttonLimpar = buttonLimpar;
	}

	public JComboBox<String> getComboProfissao() {
		return comboProfissao;
	}

	public void setComboProfissao(JComboBox<String> comboProfissao) {
		this.comboProfissao = comboProfissao;
	}
	
	public void limparTelaCadastro()
	{
		fieldCpf.setText("");
		fieldNome.setText("");
		fieldEndereco.setText("");
		comboProfissao.setSelectedIndex(0);
	}

}
