package controle;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import dao.LivroDAO;
import modelo.Livro;
import visao.JanelaLivro;

public class LivroControle implements ActionListener{
	
	private JanelaLivro janela;
	private Livro livro;
	private LivroDAO livrodao;
	

	public LivroControle(JanelaLivro janela, Livro livro) {
		
		this.janela=j;
		this.livro=livro;
		this.janela.getButtonCadastrar().addActionListener(this);
		this.janela.getButtonConsultar().addActionListener(this);
		livrodao= new LivroDAO();
		
	}


	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if (e.getActionCommand().equals("Cadastrar"))
		{
			
		}
		
	}
	
	
	

}
