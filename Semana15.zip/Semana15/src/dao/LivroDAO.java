package dao;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import modelo.Livro;

public class LivroDAO {
	
	private File arq=null;
	
	public LivroDAO()
	{
		arq = new File("livros.txt");
	}

	public boolean cadastraLivro(Livro l)
	{
		FileWriter fw=null;
		BufferedWriter bw=null;
		
		try {
			fw = new FileWriter(arq,true);
			bw = new BufferedWriter (fw);
			
			bw.write(l.toString());
			bw.flush();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
		finally 
		{
			try {
				fw.close();
				bw.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		return true;
	}
}
