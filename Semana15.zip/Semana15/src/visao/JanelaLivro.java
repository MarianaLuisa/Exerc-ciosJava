package visao;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import java.awt.Font;
import javax.swing.JLabel;
import javax.swing.JButton;

public class JanelaLivro extends JFrame {

	private JPanel contentPane;
	private JLabel labelISBN;
	private JLabel labelTela;
	private JTextField fieldISBN;
	private JLabel labelTitulo;
	private JTextField fieldTitulo;
	private JLabel labelAutor;
	private JTextField fieldAutor;
	private JButton buttonCadastrar;
	private JButton buttonConsultar;
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					JanelaLivro frame = new JanelaLivro();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public JanelaLivro() {
		setTitle("Livraria Tabajara");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		labelISBN = new JLabel("ISBN");
		labelISBN.setBounds(10, 47, 46, 14);
		contentPane.add(labelISBN);
		
		labelTela = new JLabel("TELA DE GERENCIAMENTO DE LIVROS");
		labelTela.setFont(new Font("Tahoma", Font.BOLD, 20));
		labelTela.setBounds(21, 11, 403, 14);
		contentPane.add(labelTela);
		
		fieldISBN = new JTextField();
		fieldISBN.setBounds(40, 44, 120, 20);
		contentPane.add(fieldISBN);
		fieldISBN.setColumns(10);
		
		labelTitulo = new JLabel("Título");
		labelTitulo.setBounds(170, 47, 34, 14);
		contentPane.add(labelTitulo);
		
		fieldTitulo = new JTextField();
		fieldTitulo.setBounds(201, 44, 190, 20);
		contentPane.add(fieldTitulo);
		fieldTitulo.setColumns(10);
		
		labelAutor = new JLabel("Autor");
		labelAutor.setBounds(10, 87, 34, 14);
		contentPane.add(labelAutor);
		
		fieldAutor = new JTextField();
		fieldAutor.setBounds(40, 84, 351, 20);
		contentPane.add(fieldAutor);
		fieldAutor.setColumns(10);
		
		buttonCadastrar = new JButton("Cadastrar");
		buttonCadastrar.setBounds(10, 159, 89, 23);
		contentPane.add(buttonCadastrar);
		
		buttonConsultar = new JButton("Consultar");
		buttonConsultar.setBounds(115, 159, 89, 23);
		contentPane.add(buttonConsultar);
		
		
	}

	public JLabel getLabelISBN() {
		return labelISBN;
	}

	public void setLabelISBN(JLabel labelISBN) {
		this.labelISBN = labelISBN;
	}

	public JLabel getLabelTela() {
		return labelTela;
	}

	public void setLabelTela(JLabel labelTela) {
		this.labelTela = labelTela;
	}

	public JTextField getFieldISBN() {
		return fieldISBN;
	}

	public void setFieldISBN(JTextField fieldISBN) {
		this.fieldISBN = fieldISBN;
	}

	public JLabel getLabelTitulo() {
		return labelTitulo;
	}

	public void setLabelTitulo(JLabel labelTitulo) {
		this.labelTitulo = labelTitulo;
	}

	public JTextField getFieldTitulo() {
		return fieldTitulo;
	}

	public void setFieldTitulo(JTextField fieldTitulo) {
		this.fieldTitulo = fieldTitulo;
	}

	public JLabel getLabelAutor() {
		return labelAutor;
	}

	public void setLabelAutor(JLabel labelAutor) {
		this.labelAutor = labelAutor;
	}

	public JTextField getFieldAutor() {
		return fieldAutor;
	}

	public void setFieldAutor(JTextField fieldAutor) {
		this.fieldAutor = fieldAutor;
	}

	public JButton getButtonCadastrar() {
		return buttonCadastrar;
	}

	public void setButtonCadastrar(JButton buttonCadastrar) {
		this.buttonCadastrar = buttonCadastrar;
	}

	public JButton getButtonConsultar() {
		return buttonConsultar;
	}

	public void setButtonConsultar(JButton buttonConsultar) {
		this.buttonConsultar = buttonConsultar;
	}
}
